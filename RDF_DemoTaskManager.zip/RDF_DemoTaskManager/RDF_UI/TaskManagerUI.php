
            
   
    <table class="section" id="mainTable" style=" width:70%;margin-left:12%;background-color: #f2f2f">
    <h1>Task Manager</h1>
        <tr>
            <th colspan="2">Options</th>
        </tr>
        <tr>
            <td style="background-color: #f2f2f2; padding:12%;  font-size:20px;">
                <a href="RDFView.php?ui=addtaskTemplate" style="text-decoration: none; padding: 5%; color: black;">
                    Add Task
                </a>
            </td>
            <td style="background-color: #f2f2f2; padding:12%;  font-size:20px;">
                <a href="RDFView.php?ui=showtaskTemplate" style="text-decoration: none; padding: 5%; color: black;">
                    Show Task List
                </a>
            </td>
        </tr>
    </table>
    <script>
        document.getElementById("").addEventListener("click", function() {
            document.getElementById("mainTable").style.display = "none";
            
        });
    </script>

    

<table id="taskTable">

    <h1>Task List</h1>
    <label>
        <a href="RDFView.php?ui=TaskManagerUI"><button class="button">Back</button></a>
        <button onclick="sortTasks('name')" class="button">Group by Name</button>
        <button onclick="sortTasks('status')" class="button">Group by Status</button>
        <button onclick="sortTasks('datetime')" class="button">Group by Date & Time</button>
        <button onclick="sortTasks('createdBy')" class="button">Group by Creator</button>
</label>
    
        <thead>
            <tr>
                <th>ID</th>
                <th>Task Name</th>
                <th>Status</th>
                <th>Created By</th>
                <th>Date & Time</th>
                <th>Description</th>
                <th>Actions</th>
            </tr>
        </thead>
        <tbody>
            <!-- Task rows will be inserted here -->
        </tbody>
    
    

    </table>

    <script src="RDF_ACTION/TaskManagerAction.js"></script>
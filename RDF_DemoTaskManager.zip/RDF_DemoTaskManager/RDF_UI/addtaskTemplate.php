
    <h1>Add New Task</h1>
    
        <table id="addTaskForm">
            <tr>
                <td>Task Name:</td>
                <td><input type="text" id="taskName" required class="inp"></td>
            </tr>
            <tr>
                <td>Status:</td>
                <td><select type="text" id="taskStatus" required class="inp">
                    <option value="Pending">Pending</option>
                    <option value="In Progress">In Progress</option>
                    <option value="Complete">Complete</option>
                </select></td>
            </tr>
            <tr>
                <td>Created By:</td>
                <td><input type="text" id="createdBy" required class="inp"></td>
            </tr>
            <tr>
                <td>Date & Time:</td>
                <td><input type="datetime-local" id="taskDatetime" required class="inp"></td>
            </tr>
            <tr>
                <td>Description:</td>
                <td><textarea id="taskDescription" required class="inp"></textarea></td>
            </tr>
            <tr>
                <td colspan="2">
                    <button type="button" onclick="addTask()" class="btn">Add Task</button>
                </td>
            </tr>
        

    <a href="RDFView.php?ui=TaskManagerUI"><button class="btn">Back</button></a>
 
   
</table>
 <script src="RDF_ACTION/TaskManagerAction.js"></script>
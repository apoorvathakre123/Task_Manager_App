<?php
class BVO {
    private static $file = '../RDF_DATA/TaskManagerData.json';

    public static function getTasks() {
        if (!file_exists(self::$file)) {
            return [];
        }
        $json = file_get_contents(self::$file);
        return json_decode($json, true);
    }

    public static function addTask($task) {
        $tasks = self::getTasks();
        $tasks[] = $task;
        file_put_contents(self::$file, json_encode($tasks, JSON_PRETTY_PRINT));
    }

    public static function deleteTask($id) {
        $tasks = self::getTasks();
        $tasks = array_filter($tasks, function($task) use ($id) {
            return $task['id'] !== $id;
        });
        file_put_contents(self::$file, json_encode(array_values($tasks), JSON_PRETTY_PRINT));
    }

    public static function editTask($updatedTask) {
        $tasks = self::getTasks();
        foreach ($tasks as &$task) {
            if ($task['id'] === $updatedTask['id']) {
                $task = $updatedTask;
                break;
            }
        }
        file_put_contents(self::$file, json_encode($tasks, JSON_PRETTY_PRINT));
    }
}
?>

<!-- 
GET FILE NAME THAT NEEDS TO BE EXECUTED
http://localhost//e-wallet/rdfview.php?ui=CreateDriveForm


http://localhost/RDF_DemoTaskManager/RDFView.php?ui=TaskManagerUI

-->

<?php

$uiFilePath="";

if(isset($_GET['UI']) )
{
  echo "<hr>";
  print_r($_GET);
  $uiFileName=$_GET['UI'];
  $uiFileName = 'RDF_UI/'.$uiFileName.'.php';
  echo $uiFilePath;
  echo "<hr>";
  exit();
}else if(isset($_GET['ui']) )
{
  echo "<hr>";
  //print_r($_GET);
  $uiFileName=$_GET['ui'];
  $uiFilePath = 'RDF_UI/'.$uiFileName.'.php';
  echo "File Name is : ".$uiFilePath;
  echo "<hr>";
  
}
else{
  Echo "<h1>Mention UI Template File Name</h1>";
  exit();
}

?>

<!DOCTYPE html>
<html lang="en">

<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  
  <title>Add Drive</title>
  <style>
    body {
     margin: 0;
     background-color: ghostwhite;
    }
    .container {
      max-width: 800px;
      margin: 0 auto;
      font-family: Arial, sans-serif;
      padding: 20px;
    }
    h1{
      margin:0px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
    }
    th, td {
      padding: 10px;      
      text-align: left;
      border: 1px dotted darkgray;
    }
    th {
      background-color: #f2f2f2;
    }

    .section {
      margin-top: 10px;
    }
    .section-header {
      font-size: 20px;
      font-weight: bold;
      margin-bottom: 10px;
    }
  

    form {
      display: flex;
      flex-direction: column;
    }
    .form-group {
      margin-bottom: 15px;
    }
    .form-group label {
      margin-bottom: 5px;
    }
    .form-group input {
      padding: 10px;
      width: 100%;
      box-sizing: border-box;
    }
    .button {
      padding: 10px;
      background-color: #4CAF50;
      color: white;
      border: none;
      cursor: pointer;
      border-radius: 10px;
    }


    .button,.btn {
      background-color: #4CAF50;
      color: white;
      padding: 10px 10px;
      margin: 10px;
      border: none;
      cursor: pointer;
      border-radius: 5px;
    }
    .button,.btn:hover {
        background-color: #597D35;
    }
    @media (max-width: 768px) {
        .buttons-container {
            flex-direction: column;
            align-items: center;
        }

        .form-table {
            width: 100%;
        }

        th, td {
            display: block;
            width: 100%;
            text-align: right;
        }

        th {
            text-align: center;
        }

        th::after {
            content: ":";
            padding-left: 5px;
        }

        td {
            text-align: left;
        }

        tr {
            display: flex;
            flex-direction: column;
            align-items: center;
            margin-bottom: 15px;
            border: none;
        }

        tr th, tr td {
            border: none;
        }

        tr th, tr td {
            border: 1px solid #ddd;
            width: 100%;
            box-sizing: border-box;
        }
    }

    .inp {
        width: 85%;
        padding: 8px;
        margin: 8px 0;
        border-radius:5px;
    }

    .link-button {
        text-decoration: none;
        color: white;
        display: inline-block;
    }
</style>
  
</head>

<body>
  <div style="background-color:darkgray; margin:0px; padding:10px" >
    <!-- Button to toggle the border -->
    <input type="checkbox" id="myCheckbox" checked> Show Border
    <!-- Button to Decrease text size -->
    <button id="decreaseTextButton">Decrease Text Size</button>
    <!-- Button to Increase text size -->
    <button id="IncreaseTextButton">Increase Text Size</button>
    <hr>
  </div>

  <div class="container">

      <?php include($uiFilePath); ?>
   </div>


   <script type="text/javascript">


          // Get the table and button elements
        var table1 = document.getElementById("myTable");
        var IncreaseTextButton = document.getElementById("IncreaseTextButton");
        var decreaseTextButton = document.getElementById("decreaseTextButton");


        const checkbox = document.getElementById('myCheckbox');
        checkbox.addEventListener('change', function(){
          if (checkbox.checked) {
            //alert("Check Box Checked.......");
            setTableBorderForAlltheTables("1px dotted darkgray");
          }else {
            //alert("Check Box Checked");
            setTableBorderForAlltheTables("none");
          }
        });


        function setTableBorderForAlltheTables(borderStyle){
          // Get all table elements on the page
          var tables = document.querySelectorAll('table');
          // Loop through each table and apply the desired styles
          tables.forEach(function(table) {
              setTableBorder(table, borderStyle);
          });
        }

        
        function setTableBorder(table, borderStyle){
                 table.style.border = borderStyle; 
                // Get all the cells (both <th> and <td> elements)
                const cells = table.getElementsByTagName('td');
                const headers = table.getElementsByTagName('th');                
                // Combine cells and headers into a single array
                const allCells = Array.from(cells).concat(Array.from(headers));                
                // Loop through each cell and apply the desired style
                allCells.forEach(cell => {
                     cell.style.border = borderStyle;
                });
        }

       

        IncreaseTextButton.addEventListener("click", function () {
            // Call the function to Increase the text size
            IncreaseTextSize();
        });

        decreaseTextButton.addEventListener("click", function () {
            // Call the function to Increase the text size
            decreaseTextSize();
        });
    
    // Function to Increase the font size of all text elements in the page
        function IncreaseTextSize() {
            // Get all text-containing elements
            let elements = document.querySelectorAll('p, span, div, h1, h2, h3, h4, h5, h6, td, a, b, i, u');
            // Iterate through all the elements and Increase their font size
            elements.forEach(element => {
                // Get the current font size
                let currentFontSize = window.getComputedStyle(element).fontSize;
                // Calculate the new font size
                let newFontSize = parseFloat(currentFontSize) * 1.1;
                // Update the element's font size
                element.style.fontSize = `${newFontSize}px`;
            });
        }

         // Function to Increase the font size of all text elements in the page
        function decreaseTextSize() {
            // Get all text-containing elements
            let elements = document.querySelectorAll('p, span, div, h1, h2, h3, h4, h5, h6, td, a, b, i, u');
            // Iterate through all the elements and Increase their font size
            elements.forEach(element => {
                // Get the current font size
                let currentFontSize = window.getComputedStyle(element).fontSize;
                // Calculate the new font size
                let newFontSize = parseFloat(currentFontSize) * 0.9;
                // Update the element's font size
                element.style.fontSize = `${newFontSize}px`;
            });
        }
  

  </script>
    

</body>

</html>
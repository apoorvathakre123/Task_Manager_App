<?php
require_once '../RDF_BVO/TaskManagerBVO.php';

$data = json_decode(file_get_contents('php://input'), true);
$action = $data['action'];

switch ($action) {
    case 'addTask':
        addTask($data['task']);
        break;
    case 'getTasks':
        getTasks();
        break;
    case 'deleteTask':
        deleteTask($data['id']);
        break;
    case 'editTask':
        editTask($data['task']);
        break;
    case 'sortTasks':
        sortTasks($data['criteria']);
        break;
    default:
        echo json_encode(['success' => false, 'message' => 'Invalid action']);
        break;
}

function addTask($task) {
    $tasks = BVO::getTasks();
    foreach ($tasks as $existingTask) {
        if ($existingTask['name'] === $task['name']) {
            echo json_encode(['success' => false, 'message' => 'Task name must be unique']);
            return;
        }
    }
    BVO::addTask($task);
    echo json_encode(['success' => true, 'message' => 'Task added successfully']);
}

function getTasks() {
    $tasks = BVO::getTasks();
    echo json_encode(['success' => true, 'tasks' => $tasks]);
}

function deleteTask($id) {
    BVO::deleteTask($id);
    echo json_encode(['success' => true, 'message' => 'Task deleted successfully']);
}

function editTask($task) {
    BVO::editTask($task);
    echo json_encode(['success' => true, 'message' => 'Task updated successfully']);
}

function sortTasks($criteria) {
    $tasks = BVO::getTasks();
    usort($tasks, function($a, $b) use ($criteria) {
        return strcmp($a[$criteria], $b[$criteria]);
    });
    echo json_encode(['success' => true, 'tasks' => $tasks]);
}
?>

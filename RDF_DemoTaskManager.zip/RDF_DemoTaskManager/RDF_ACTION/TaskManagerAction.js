function addTask() {
    const taskName = document.getElementById('taskName').value.trim();
    const taskStatus = document.getElementById('taskStatus').value.trim();
    const createdBy = document.getElementById('createdBy').value.trim();
    const taskDatetime = document.getElementById('taskDatetime').value.trim();
    const taskDescription = document.getElementById('taskDescription').value.trim();

    if (taskName && taskStatus && createdBy && taskDatetime && taskDescription) {
        const task = {
            id: Math.random().toString(36).substr(2, 4),
            name: taskName,
            status: taskStatus,
            createdBy: createdBy,
            datetime: taskDatetime,
            description: taskDescription
        };

        fetch('RDF_BW/TaskManagerBW.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ action: 'addTask', task: task })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            if (data.success) {
                window.location.href = 'RDFView.php?ui=showtaskTemplate';
            }
        });
    } else {
        alert('All fields are required!');
    }
}


function loadTasks() {
    fetch('RDF_BW/TaskManagerBW.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action: 'getTasks' })
    })
    .then(response => response.json())
    .then(data => {
        const taskTableBody = document.querySelector('#taskTable tbody');
        taskTableBody.innerHTML = ''; // Clear existing rows

        data.tasks.forEach(task => {
            const row = document.createElement('tr');

            row.innerHTML = `
                <td>${task.id}</td>
                <td>${task.name}</td>
                <td>${task.status}</td>
                <td>${task.createdBy}</td>
                <td>${task.datetime}</td>
                <td>${task.description}</td>
                <td>
                    <button onclick="editTask('${task.id}')" class="btn">Edit</button>
                    <button onclick="deleteTask('${task.id}')" class="btn">Delete</button>
                </td>
            `;

            taskTableBody.appendChild(row);
        });
    });
}

function deleteTask(id) {
    if (confirm('Are you sure you want to delete this task?')) {
        fetch('RDF_BW/TaskManagerBW.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ action: 'deleteTask', id: id })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            if (data.success) {
                loadTasks(); // Reload the tasks after deletion
            }
        });
    }
}

function editTask(id) {
    const taskName = prompt('Enter new task name');
    const taskStatus = prompt('Enter new status');
    const taskDescription = prompt('Enter new description');

    if (taskName && taskStatus && taskDescription) {
        const updatedTask = {
            id: id,
            name: taskName,
            status: taskStatus,
            description: taskDescription
        };

        fetch('RDF_BW/TaskManagerBW.php', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({ action: 'editTask', task: updatedTask })
        })
        .then(response => response.json())
        .then(data => {
            alert(data.message);
            if (data.success) {
                loadTasks(); // Reload the tasks after editing
            }
        });
    }
}

function sortTasks(criteria) {
    fetch('RDF_BW/TaskManagerBW.php', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify({ action: 'sortTasks', criteria: criteria })
    })
    .then(response => response.json())
    .then(data => {
        const taskTableBody = document.querySelector('#taskTable tbody');
        taskTableBody.innerHTML = ''; // Clear existing rows

        data.tasks.forEach(task => {
            const row = document.createElement('tr');

            row.innerHTML = `
                <td>${task.id}</td>
                <td>${task.name}</td>
                <td>${task.status}</td>
                <td>${task.createdBy}</td>
                <td>${task.datetime}</td>
                <td>${task.description}</td>
                <td>
                    <button onclick="editTask('${task.id}')" class="btn">Edit</button>
                    <button onclick="deleteTask('${task.id}')" class="btn">Delete</button>
                </td>
            `;

            taskTableBody.appendChild(row);
        });
    });
}

// On page load, call loadTasks function for showtaskTemplate.php
if (document.body.contains(document.querySelector('#taskTable tbody'))) {
    loadTasks();
}
